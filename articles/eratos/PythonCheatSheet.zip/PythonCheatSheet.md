## Floating point precision

`0.1 + 0.2 - 0.3 != 0`

[Floating Point](https://docs.python.org/2/tutorial/floatingpoint.html)

## Variable Names

1. Names cannot start with a number.
2. There can be no spaces.
3. You cannot use special characters.
4. Best practice to keep them lowercase.
5. Avoid words that have special meaning like "list" or "str".
6. If you wish to **initialize a variable with no value**, use `a = None`.

### Characteristics

1. Dynamic typing -> beware of `type()` bugs.
2. Restarting the kernel, resets all the variables.

#### Strings

1. Single or double quotes.
2. Ordered sequence.
3. Index with `[]`, zero based.
4. Slicing: `[start:stop:step]`.
5. `\n` makes an enter (escape) basically.
6. `len()` function is useful for the length.
7. Negative index starts at -1.
8. `[2:]` goes from zero to the end.
9. "Stop" is up to, but not included.
10. Reverse the string `[::-1]`.
11. You can also not name variables, but do it. directly, e.g, `'Hello'[-2]`.
12. Strings are **Immutable**.
13. Can do concatenation with `+`.
14. Can do multiplication of letters, like 'z'.
15. Method or function without **()** yields the description of the function %.
16. The Split function can split based on an item of the function.
17. `.format` can help you insert words into a string in different order.
18. You can also use a more modern formatting as in `print(f'Hello, his name is {name}')`.
19. The `.join()` function is very useful to glue together strings.

#### Float Formatting

1. It follows "{value:width.precision f}", like `print("The result was{r:10.5f}".format(r = result))`.

#### Lists

1. Ordered sequences that can hold a variety of object types.
2. They use `[]`.
3. You can index, concatenate, split, etc.
4. You can change elements inside the List, it's **mutable**.
5. `.append()` adds another element to the end of the list.
6. `.pop()` takes out the last item in the List or with indexes.
7. Be very careful with the `.sort()` method!
8. Lists can be **nested**, and you can index them with more than one dimensions.
9. You can repeat values using `[0]*3` for example.

#### Dictionaries

1. Unordered mappings; gives back the key-associated value.
2. `my_dict = {'key1':'value', 'key2':'value'}`.
3. Can have multiple data types inside it.
4. Can add a new key value pair through a simple assignment: `d['k1'] = 'value'`.
5. `d.items()` gives the tuples of the values.
6. Keys can be different than strings.
7. There is a way to go around the unordered characteristic of a dictionary through **ordereddict**.
8. They are not **immutable**.

#### Tuples

1. They are **immutable** and done with `()`.
2. Indexes work with `[]`.
3. There are not a lot of methods associated with them.
4. They can be nested and have multiple data types.

#### Sets

1. Unordered collections of unique elements.
2. There can only be one representative of the same object.
3. It won't repeat values.
4. `myset.add()`.
5. You can reduce a list of repeated values.
6. Can be used to separate the letters of string through `set()`.
7. They use `{}`.

#### Booleans

1. Operators yield **True** and **False** values.
2. Values `True` and `False` should have capital lettters.

## Files

1. `pwd` will give you where your Jupyter notebook is.
2. In Jupyter, this works `%%writefile myfile.txt Hello this is a text file`.
3. `myfile.read()`, if you try to read it two times, it won't work, you should reset the cursor with `seek(0)`.
4. `myfile.readlines()` is more convenient usually.
5. For other folders: `myfile = open("C:\\Path\\Path")`, careful with the double backslash.
6. It's good practice to close the file with `close()`.
7. You can use a file as a variable `with open('myfile.txt') as my_new_file:` and then put stuff inside the indentation.
8. `SHIFT+TAB` gives you specifications of the function.
9. Different modes: 'r', 'w', 'a', 'r+', 'w+'.
10. `mode = 'w'` will create the file if it doesn't exist already.

## Useful for Practicing

Basic Practice:

http://codingbat.com/python

More Mathematical (and Harder) Practice:

https://projecteuler.net/archives

List of Practice Problems:

http://www.codeabbey.com/index/task_list

A SubReddit Devoted to Daily Practice Problems:

https://www.reddit.com/r/dailyprogrammer

A very tricky website with very few hints and touch problems (Not for beginners but still interesting)

http://www.pythonchallenge.com/

## Comparison Operators

1. Capitalization counts when comparing Strings.
2. `2.0 == 2` is `True`.
3. Can do boolean chains, like `1 < 2 < 3`, which is sequential from the left to the right.
4. `not` is the opposite Boolean.
5. `elif` serves as an intermediate `else`.

## Loops

1. `for i in a:`.
2. `for num in mylist:` iterates through a List.
3. You can use `for _ in mylist` to do it in a shorter format when you want to iterate through the list.
4. You can do tuple unpacking with, for example, `for a,b in mylist: print(a) print(b)`.
5. You can do something similar with dictionaries: `for key,value in d.items():`.
6. `else` does work with `while`.
7. **Syntax fillers and sometimes necessary**:
	1. `Break`: breaks out of the current enclosing loop.
	2. `Continue`: goes to the top of the closes enclosing loop.
	3. `Pass`
8. `range` is go up to but not including.
9. With `enumerate()` to get the index counter and the object in the iteration; `zip()` has a similar behavior.
10. `in` is very useful to find Values.
11. You can also do **List Comprehension** with e.g. `mylist = [letter for letter in mystring]`, you can also do operations with `letter` inside it.
12. In a `for`, if you put a `break` and you never break it, you can put an `else` statement.

## Libraries

1. E.g.: `from random import shuffle`.

## UI

1. E.g.: `name = input('Enter a number here:')`, you can turn it into a number through, for exmaple, `int(name)`.

## Functions

1. `return` allows us to assign values do the output.
2. With triple quotes (`''' '''`), you can add **documentation**.
3. You can assign default values for the parameters with the `=` sign.
4. You don't need an `if` statement for `'dog' in mystring.lower()` because it is already a boolean. You can simple use `return`.
5. `*args` makes a **tuple** for the arguments that go into a function, to make it more flexible. You can use anything with an `*`, but, by convention, you should stick to `*args`.
6. `**kwargs` is very similar, but for Dictionaries.
7. You can `return` Boolean statements without `if` statements. Like `return a == b`.
8. **Iterating** through a function easily with a `for`: use `map()`. You can do it easily with something like `list(map(myfunc,mynums))`. The `filter` function acts in a similar fashion.
8. **Lambda Expressions**: These are anonymous fucntions used to save space and in conjunction with functions like `map` or `filter`. Complex functions should not be used with it.

#### Nested Statements and Scope

1. **LEGB RULE**, the search sequence used for variables in Python:
	1. **Local**
	2. **Enclosing Function Locals** (function that encloses the function)
	3. **Global** (module)
	4. **Built-in** (Python)

2. The reassignment only have a **scope** local to the function.
3. You can change the global value with `global` though.

## Object Oriented Programming

1. Defining **objects** with **classes**.
2. For every individual word in a class name, there should be a capital letter. (variables should be lowercase).
3. For **attributes**: `def __init__(self, attributes): self.attribute = attribute`
4. For **inherent** attributes, you can create attributes before `__init__`. In this case you don't use `*self*`.
5. Atributes don't have `()`, only **Methods** do.
6. If you wanna use the object's characteristics, you have to use `self`.
7. You can also create attributes that are not in the given parameters.
8. If you wanna call **class object attributes**, you have 2 ways: `self.attribute` or `NameOfTheClass.attribute`.
9. **Inheritance**: You can use a class as a parameter of another class. Inside its `__init__`, you simply initialize the inherited class, e.g., for a *dog* class, `Animal.__init__(self)`.
10. You can always overwrite methods with the more local class by using the same name.
11. **Polymorphism**: it's when you have a method that has the same name for 2 or more classes. For example, *speak* could be used for different pets: `def pet_speak(pet): print(pet.speak())`.
12. Usually, people don't specify those functions for the upper level class, putting an error inside it: `raise NotImplementedError("You're not supposed to do this")`.
13. **Special Methods**: `__str__` for printing, use `return` directly; `__len__` for the length; `__del__` for printing a message when you delete an object.

## Modules and Packages

1. You can install packages through `pip install` command directly inside your Command Prompt.
2. **Modules** are just `.py` scripts. **Packages** are a collection of **Modules**. **But** you need a key `__init__.py` file so Python can recognize it as a package.
3. You can simply call functions with `from mymodule import my_func`.
4. Subfolder use dots, like in `mainpackage.subpackage import subscript`.
5. `if __name__ == '__main__'` is equivalent to checking if the name of the main() that's being executed is the same as the name of the file.

## Errors and Exception Handling

1. There are three main keywords:
	1. `try`: block that may lead to an error.
	2. `except`: block of code that will be executed in case there is an error in the `try` block.
	3. `finally`: final block of code to be executed, regardless of an error.
2. We can also use a **try-except-else** block, which will only execute the code inside the `else` condition if we get no error.
3. You can do `except` for specific types of errors.
4. If you're working with inputs, you could use `while` loops also.

## Testing Tools

1. **pylint**: this is a library that looks at your code and reports back possible issues.
	1. If you execute your code through Command Prompt typing `pylint filename.py`, you will receive the error with a `E:`.
	2. You can also get a report with it.
	3. Grade 10/10 is very difficult.
2. **unittest**: this built-in library will allow to test your own programs and check if you are getting desired outputs.
	1. A typical example:
	```python
	# First File
	def cap_text(text):
	    '''
	    Input a string and output
	    the same string with the first
	    letter capitalized
	    '''
	    return text.title()

	# Second File
	import unittest
	import cap

	class TestCap(unittest.TestCase):
	    def test_one_word(self):
	        text = 'python'
	        result = cap.cap_text(text)
	        self.assertEqual(result,'Python')

	    def test_multiple_words(self):
	        text = 'monty python'
	        result = cap.cap_text(text)
	        self.assertEqual(result,'Monty Python')

	if __name__ == '__main__':
	    unittest.main()
	```

## Decorators and Nested Functions

1. Decorators allow you to tack on extra functionality to an already existing function.
2. Nested functions can only be called inside the global function.
	1. You can do functions that return a function and then pass it on to an object, which will turn it into the assigned function.
	2. You can even call functions to execute alien functions inside it, e.g., `some_func(some_other_func)`. Notice that `some_other_func` doesn't have parenthesis.
3. An example of a decorator is wrapping a function with more text, to maybe make it more comprehensible. It's much like wrapping a gift. Decorators are usually used within wep frameworks such as *Django* and *Flask*.
4. An example:
	```python
	def new_decorator(original_func):

	    def wrap_func():

	        print('Some extra code, before the original funtion')

	        original_func()

	        print('Some extra code, after the original function!')

	    return wrap_func

	def func_needs_decorator():
			    print('I want to be decorated')

	decorated_func = new_decorator(func_needs_decorator)

	decorated_func()
	```

## Generators

1. Generators make better use of space in your memory by handling on the go numbers. One example would be the `range()` function. You would have to cast `list()` on the `range()` function in order to get its elements.
2. To use generators, use `yield`:
	```python
	def create_cubes(n):
    result = []
    for x in range(n):
        yield x**3
	```
3. Another useful function is the `next()`, which will give you the next iteration of the function.
4. `iter()` turns an object that's not iterable, like a string in an iterable one.
5. You can also do **Generator Comprehension**: much like **List Comprehension**, you will iterate through a list, but now with much memory use. Note that the only change is that instead of using `[]`, we use `()`:
	```python
	my_list = [1,2,3,4,5]

	gencomp = (item for item in my_list if item > 3)
	print(gencomp)
	for item in gencomp:
	    print(item)
	```

## Collections Module

1. `Counter()`: input a list and outputs a dictionary with the counts of the occurrences of each item. (`from collections import Counter`)

## Timing your Code

1. `import timeit`
2. Example: `timeit.timeit('"-".join(str(n) for n in range(100))',number = 10000)`
3. The `map()` function is faster: `timeit.timeit('"-".join(map(str,range(100)))', number = 10000)`
4. A more **succint** (the `%` is the *magic function* in Jupyter) way of doing it in Jupyter is `%timeit "-".join(map(str,range(100)`

## Python Debugger

1. **This is extremely useful**. Instead of putting `print()` to find out what's going on inside your code, you can just put a `pdb.set_trace()` where things are going wrong. Even whole expressions work. To quit the command, just type `q`. (**You need**: `import pdb`)

# Important Notes & Miscellanea

1. You can **sum** over **strings**, but you can only **append** over **lists**.
2. Use **DOCSTRINGS** for long programs with lots of functions.
3. Be careful with comma assignments, they are different than putting things in another line.
4. `\` breaks lines of code. `\n` is an *enter* in a `print()` call, as `\t` is a *tab*.
5. Be careful with what is inside a `__init__` and what's outside it!
6. Don't forget to put `self` as the first argument in the methods.
7. Error and exception handling is incredibly useful
8. `while True` + `break` is very useful.
9. `1` and `0` are treated as booleans also. And anything above `1` is also treated as `True`.
10. Functions are objects that can be passed on to another object. So, even if you `del` the original object, the former receivers of it will still have it.
11. Be careful with tuple matching, it isn't your normal C programming:
	```python
	a,b = b,a+b # this is actually a Fibonacci sequence
	```
12. **Very Important**: *Copy-on-slice!* If you do `b = a` and then change `b` later on, `a` will also change. If you check `a` and `b` ids through `id()`, they are the same. One way to change this is `b = a[:]`, slicing.
13. Iterating through lists is extremely useful and important:
	```python
	def data_scientists_who_like(target_interest):
	return [user_id
	        for user_id, user_interest in interests
	        if user_interest == target_interest]
	```
14. Python functions are *first-class*, which means you can pass them entirely to variables.
15. You can use `"""` for multiline strings.
16. You can easily **check for elements in a list** with the `in` operator, e.g., `1 in [1,2,3]`.
17. `_,y = [1,2]` throws away the first value from the unpacking.
18. Tuples don't *need* parenthesis.
19. `defaultdict` is useful to check for keys and deal with dictionaries. For example `dd_ list[2].append(1)` cannot be used directly without it. You need to `from collections import defaultdict` first though.
20. **Counter()**: turns a sequence of values into a `defaultdict`-like object mapping keys to counts. It also has a `most_common` method that is very useful.
	```python
	from collections import Counter
	c = Counter([0, 1, 2, 0]) # c is (basically) { 0 : 2, 1 : 1, 2 : 1
	```
21. Check out the `all()` and `any` functions. And also the unusual syntax of `first_char = s and s[0]` and `safe_x = x or 0`
22. A quick way of generating random numbers (for reproducible results, use also `random.seed()`): `n_uniform_randoms = [random.random() for _ in range(n)]`
23. The `functools.partial` (`from functools import partial`) makes function call inside functions more succint:
`two_to_the = partial(exp,2)` and then `print(two_to_the(3))`
24. You can get the index and the element of a list with the `enumerate()` function (if you just want the indexes: `for i, _ in enumerate(documents): do_something(i)`):
```python
for i, document in enumerate(documents):
	do_something(i,document)
```
25. **Argument Unpacking**: you can **zip** elements with, for example `zip(list1,list2)`; and unzip them with `letters,numbers = zip(*pairs)`. The asterisk unpacks the arguments pair by pair. You can do that with any function, such as `add(*[1,2])`. **zip** is very useful for tuple unpacking:
	```python
	def dot(v, w):
	"""v_1 * w_1 + ... + v_n * w_n"""
	return sum(v_i * w_i
	for v_i, w_i in zip(v, w))
	```
26. The more *pythonic* way of return with **if** statements (diagonal matrix): `return 1 if i == j else 0`.
27.

#### A Note on Objects:

Objects are a collection of methods and attributes. They are entities which help to structure your code in a better way. These are some useful directives:

1. Always make an algorithmic sketch of what you want to code, this way patterns will come out more easily.
2. Is this set of functions and attributes able to configure a **class**? Is it necessary?

## Visualizing Data

1. Be careful with the **autoformatting** of the axes. It can mislead you.
2. Plotting graphs is generally quite simple, `plt.plot` or `plt.scatter` or `plt.bar` (`from matplotlib import pyplot as plt`).
3. Other resources:
	1. **seaborn** is built on top of matplotlib and allows you to easily produce prettier (and	more complex) visualizations.
	2. **D3.js** is a JavaScript library for producing sophisticated interactive visualizations for the web. Although it is not in Python, it is both trendy and widely used, and it is well worth your while to be familiar with it.
	3. **Bokeh** is a newer library that brings D3-style visualizations into Python.
	ggplot is a Python port of the popular R library
	4. **ggplot**, which is widely used for creating “publication quality” charts and graphics. It’s probably most interesting if you’re already an avid ggplot2 user, and possibly a little opaque if you’re not.

## Curiosities:

1. **Zen of Python**: `import this`
2. Python 2.7 uses integer division by default.

# Questions

1. In Milestone Project 2, why can't I access the `deck` attribute from outside directly?
